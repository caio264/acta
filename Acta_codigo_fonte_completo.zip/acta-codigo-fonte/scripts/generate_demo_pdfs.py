from pathlib import Path
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.colors import HexColor
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak
from reportlab.lib.units import cm

OUT = Path(__file__).resolve().parents[1] / "dist" / "demo"
OUT.mkdir(parents=True, exist_ok=True)
INK, GRAY, ORANGE, LIGHT = HexColor("#11110F"), HexColor("#66655F"), HexColor("#E85D2A"), HexColor("#F3F2EE")
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="DocTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=17, leading=21, textColor=INK, alignment=TA_CENTER, spaceAfter=14))
styles.add(ParagraphStyle(name="Meta", parent=styles["Normal"], fontName="Helvetica", fontSize=8.5, leading=12, textColor=GRAY, spaceAfter=12))
styles.add(ParagraphStyle(name="H", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=11, leading=14, textColor=INK, spaceBefore=10, spaceAfter=6))
styles.add(ParagraphStyle(name="Body2", parent=styles["BodyText"], fontName="Helvetica", fontSize=9.5, leading=14, textColor=INK, spaceAfter=8))
styles.add(ParagraphStyle(name="Notice", parent=styles["BodyText"], fontName="Helvetica-Bold", fontSize=8, leading=11, textColor=ORANGE, spaceAfter=12))

def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(HexColor("#DDDCD5")); canvas.line(2*cm, 1.35*cm, 19*cm, 1.35*cm)
    canvas.setFont("Helvetica", 7.5); canvas.setFillColor(GRAY)
    canvas.drawString(2*cm, .95*cm, "ACTA · CASO ACADÊMICO FICTÍCIO")
    canvas.drawRightString(19*cm, .95*cm, f"Página {doc.page}")
    canvas.restoreState()

def make_pdf(name, title, subtitle, sections):
    doc = SimpleDocTemplate(str(OUT / name), pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=1.8*cm)
    story = [Paragraph("acta.", styles["H"]), Paragraph(title, styles["DocTitle"]), Paragraph(subtitle, styles["Meta"]), Paragraph("DOCUMENTO INTEGRALMENTE FICTÍCIO · USO EXCLUSIVO NA DEMONSTRAÇÃO ACADÊMICA", styles["Notice"])]
    for heading, body in sections:
        story += [Paragraph(heading, styles["H"]), Paragraph(body, styles["Body2"])]
    doc.build(story, onFirstPage=footer, onLaterPages=footer)

case = "Processo fictício nº 0001234-56.2026.8.26.0100 · 12ª Vara Cível da Capital/SP"
make_pdf("01-peticao-inicial-ficticia.pdf", "PETIÇÃO INICIAL FICTÍCIA", case, [
    ("Partes", "Autora: Aurora Tecnologia Ltda. Ré: Logística Delta S.A."),
    ("Fatos", "Em 10 de janeiro de 2026, as partes celebraram contrato para transporte e entrega de 120 equipamentos eletrônicos até 31 de janeiro de 2026. A entrega ocorreu apenas em 18 de fevereiro de 2026. A autora afirma que o atraso impediu o cumprimento de contrato firmado com terceiro."),
    ("Prejuízo alegado", "A Aurora Tecnologia sustenta ter suportado multa contratual de R$ 30.000,00 e despesas emergenciais de R$ 18.000,00, totalizando R$ 48.000,00."),
    ("Pedidos", "Citação da ré; condenação ao pagamento de R$ 48.000,00; correção monetária; juros; custas e honorários. Documentos citados: contrato de transporte, comprovante de entrega e nota de débito do cliente final."),
])
make_pdf("02-contestacao-ficticia.pdf", "CONTESTAÇÃO FICTÍCIA", case, [
    ("Síntese da defesa", "A Logística Delta reconhece que a entrega ocorreu em 18 de fevereiro de 2026, mas sustenta que o atraso decorreu de enchentes que interromperam a rota entre 22 e 29 de janeiro."),
    ("Argumentos", "A ré invoca força maior e afirma ter comunicado a autora por e-mail. Também contesta o vínculo entre o atraso e a multa aplicada pelo terceiro, alegando ausência de prova do dano e possibilidade de entrega por rota alternativa contratada pela própria autora."),
    ("Pedidos", "Improcedência dos pedidos. Subsidiariamente, redução do valor indenizatório e exclusão das despesas emergenciais. Produção de prova documental suplementar e testemunhal."),
])
make_pdf("03-decisao-ficticia.pdf", "DECISÃO INTERLOCUTÓRIA FICTÍCIA", case, [
    ("Relatório", "Ação indenizatória proposta por Aurora Tecnologia Ltda. em face de Logística Delta S.A. A ré apresentou contestação e alegou força maior."),
    ("Fundamentação", "A ocorrência de enchentes e sua relação com o atraso exigem produção de prova. Também deverá ser comprovado o nexo entre a entrega tardia e os prejuízos indicados pela autora."),
    ("Decisão", "Fixo como pontos controvertidos: a inevitabilidade do evento, a existência de comunicação prévia, o nexo causal e a extensão dos danos. As partes deverão indicar provas em 15 dias. Designo audiência de conciliação para 15 de junho de 2026, às 14h."),
])

report = SimpleDocTemplate(str(OUT / "relatorio-ao-cliente-demonstrativo.pdf"), pagesize=A4, rightMargin=2*cm, leftMargin=2*cm, topMargin=2*cm, bottomMargin=1.8*cm)
story = [Paragraph("acta.", styles["H"]), Paragraph("RELATÓRIO DEMONSTRATIVO AO CLIENTE", styles["DocTitle"]), Paragraph("Cliente fictício: Aurora Tecnologia Ltda. · Atualizado em 22/05/2026", styles["Meta"]), Paragraph("CONTEÚDO GERADO PARA DEMONSTRAÇÃO. NÃO CONSTITUI ANÁLISE JURÍDICA REAL.", styles["Notice"])]
for heading, body in [
    ("1. Resumo do caso", "A empresa busca indenização de R$ 48.000,00 em razão do atraso na entrega de equipamentos. A transportadora reconhece o atraso, mas alega enchentes e ausência de prova do prejuízo."),
    ("2. Situação atual", "A contestação foi apresentada e o processo está em fase de organização das provas. O juízo definiu quatro pontos controvertidos e marcou audiência de conciliação para 15 de junho de 2026."),
    ("3. Pontos favoráveis", "A data contratual e a data efetiva da entrega são admitidas pelas duas partes. Existem documentos que indicam o valor da multa suportada pela cliente."),
    ("4. Pontos de atenção", "Será necessário demonstrar o nexo entre o atraso e cada prejuízo. A alegação de força maior dependerá das provas sobre as enchentes, rotas disponíveis e comunicação enviada pela transportadora."),
    ("5. Próximos passos", "Reunir o contrato com o cliente final, comprovantes de pagamento da multa, comunicações trocadas com a transportadora e documentos sobre alternativas de entrega. Preparar proposta e limites para a audiência de conciliação."),
]:
    story += [Paragraph(heading, styles["H"]), Paragraph(body, styles["Body2"])]
data = [["Data", "Evento", "Fonte"], ["10/01/2026", "Contrato celebrado", "Petição"], ["18/02/2026", "Entrega realizada", "Petição e contestação"], ["20/05/2026", "Pontos controvertidos fixados", "Decisão"], ["15/06/2026", "Audiência de conciliação", "Decisão"]]
t = Table(data, colWidths=[3*cm, 8.5*cm, 5*cm]); t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),INK),("TEXTCOLOR",(0,0),(-1,0),HexColor("#FFFFFF")),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTNAME",(0,1),(-1,-1),"Helvetica"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),.4,HexColor("#D8D7D0")),("BACKGROUND",(0,1),(-1,-1),LIGHT),("VALIGN",(0,0),(-1,-1),"TOP"),("TOPPADDING",(0,0),(-1,-1),7),("BOTTOMPADDING",(0,0),(-1,-1),7)])); story += [Spacer(1,8), Paragraph("6. Cronologia resumida", styles["H"]), t]
report.build(story, onFirstPage=footer, onLaterPages=footer)
print(f"Arquivos gerados em {OUT}")
